package com.unitbv.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class JDBCAndSqlInjectionExample {
	
	private static final Logger logger = LoggerFactory.getLogger(JDBCAndSqlInjectionExample.class);
	
	public static void main(String[] argv) throws SQLException {

		registerPostgreSQLDriver();

		try(Connection connection = getConnection())
		{

			if (connection != null) {
				logger.debug("You made it, take control your database now!");
			} else {
				logger.error("Failed to make connection!");
				return;
			}
			
			executeSelectWhichPreventsSqlInjection(connection, "Muffin - Mix - Bran And Maple 15l'; DELETE FROM product where product_id=1005");
			executeSelectWhichPreventsSqlInjection(connection, "Muffin - Mix - Bran And Maple 15l");
			
			executeSelectVulnerableToSqlInjection(connection, "Muffin - Mix - Bran And Maple 15l'; DELETE FROM product where product_id=1005");
			executeSelectVulnerableToSqlInjection(connection, "Muffin - Mix - Bran And Maple 15l'; DELETE FROM product where product_id=1005 --");
			executeSelectVulnerableToSqlInjection(connection, "Muffin - Mix - Bran And Maple 15l'; DELETE FROM order_product where product_id=1005; DELETE FROM product where product_id=1005 --");
			executeSelectVulnerableToSqlInjection(connection, "Muffin - Mix - Bran And Maple 15l'; DELETE FROM warehouse_product where product_id=1005; DELETE FROM order_product where product_id=1005; DELETE FROM product where product_id=1005 --");
		}
	}

	private static void executeSelectVulnerableToSqlInjection(
			Connection connection, String productName) {
		try
		{
			String query = "SELECT * FROM product where name='"+productName+"'";
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			dispResultSet(rs);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		
	}

	private static void executeSelectWhichPreventsSqlInjection(
			Connection connection, String productName) {
		try
		{
			String query = "SELECT * FROM product where name=?";
			PreparedStatement pStmt = connection.prepareStatement(query);
			pStmt.setString(1, productName);
			ResultSet rs = pStmt.executeQuery();
			dispResultSet(rs);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage(), e);
		}
	}

	private static Connection getConnection() {
		Connection connection = null;

		try {

			connection = DriverManager.getConnection(
					"jdbc:postgresql://127.0.0.1:5432/vanzari", "postgres",
					"1q2w3e");

		} catch (SQLException e) {

			logger.error("Connection Failed! Check output console", e);
			return null;

		}
		return connection;
	}

	private static void registerPostgreSQLDriver() {
		logger.debug("-------- PostgreSQL JDBC Connection Testing ------------");

		try {
			//This will load the driver, and while loading, the driver will automatically register itself with JDBC.
			//Loads and initializes the Postgresql driver. Any static initializer block is invoked.
			//Each driver has a static initializer block that registers an instance of the driver with DriverManager
			//DriverManager.registerDriver(new Driver());
			
			//https://github.com/pgjdbc/pgjdbc/blob/master/pgjdbc/src/main/java/org/postgresql/Driver.java
			Class.forName("org.postgresql.Driver");

		} catch (ClassNotFoundException e) {

			logger.error("Where is your PostgreSQL JDBC Driver? "
					+ "Include in your library path!", e);
			return;

		}

		logger.debug("PostgreSQL JDBC Driver Registered!");
	}
	
	private static void dispResultSet(ResultSet rs) throws SQLException {
		int i;
		// preia ResultSetMetaData. Acestea vor fi folosite pentru
		// antetele de coloana
		ResultSetMetaData rsmd = rs.getMetaData();
		// preia numarul de coloane
		int numCols = rsmd.getColumnCount();
		// afiseaza antetele coloanelor
		StringBuilder sb = new StringBuilder();
		for (i = 1; i <= numCols; i++) {
			if (i > 1)
				sb.append(",");
			sb.append(rsmd.getColumnLabel(i));
		}
		logger.info(sb.toString());
		
		// afiseaza toate datele din tabel
		boolean more = rs.next();
		while (more) {
			sb.delete(0, sb.length());
			// trece de la un rand la altul afisand datele
			for (i = 1; i <= numCols; i++) {
				if (i > 1)
					sb.append(",");
				sb.append(rs.getString(i));
			}
			logger.info(sb.toString());
			// incarca urmatoarul rand
			more = rs.next();
		}
	}
}
