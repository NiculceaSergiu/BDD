--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.0
-- Dumped by pg_dump version 10.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.warehouse_product DROP CONSTRAINT warehouse_warehouse_fk;
ALTER TABLE ONLY public.warehouse_product DROP CONSTRAINT warehouse_product_product_id_fk;
ALTER TABLE ONLY public.warehouse_product DROP CONSTRAINT product_id_fk;
ALTER TABLE ONLY public.order_product DROP CONSTRAINT product_id_fk;
ALTER TABLE ONLY public.order_product DROP CONSTRAINT order_id_fk;
ALTER TABLE ONLY public."order" DROP CONSTRAINT client_id_fk;
ALTER TABLE ONLY public.client DROP CONSTRAINT address_zip_code_fk;
DROP INDEX public.fki_warehouse_warehouse_fk;
DROP INDEX public.fki_warehouse_product_product_id_fk;
DROP INDEX public.fki_product_id_fk;
DROP INDEX public.fki_order_id_fk;
DROP INDEX public.fki_client_id_fk;
DROP INDEX public.fki_address_zip_code_fk;
ALTER TABLE ONLY public.address DROP CONSTRAINT zip_code_unique;
ALTER TABLE ONLY public.warehouse_product DROP CONSTRAINT warehouse_product_unique;
ALTER TABLE ONLY public.warehouse_product DROP CONSTRAINT warehouse_product_pkey;
ALTER TABLE ONLY public.warehouse DROP CONSTRAINT warehouse_pkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_pkey;
ALTER TABLE ONLY public.product DROP CONSTRAINT product_id_unique;
ALTER TABLE ONLY public.order_product DROP CONSTRAINT order_product_pkey;
ALTER TABLE ONLY public."order" DROP CONSTRAINT order_pkey;
ALTER TABLE ONLY public."order" DROP CONSTRAINT order_id_unique;
ALTER TABLE ONLY public.order_product DROP CONSTRAINT order_id_product_id_unique;
ALTER TABLE ONLY public.product DROP CONSTRAINT name_unique;
ALTER TABLE ONLY public.client DROP CONSTRAINT client_pkey;
ALTER TABLE ONLY public.client DROP CONSTRAINT client_id_unique;
ALTER TABLE ONLY public.warehouse DROP CONSTRAINT city_unique;
ALTER TABLE ONLY public.address DROP CONSTRAINT address_pkey;
ALTER TABLE public.product ALTER COLUMN product_id DROP DEFAULT;
ALTER TABLE public."order" ALTER COLUMN order_id DROP DEFAULT;
ALTER TABLE public.client ALTER COLUMN client_id DROP DEFAULT;
DROP TABLE public.warehouse_product;
DROP TABLE public.warehouse;
DROP VIEW public.product_total_quantity_sold;
DROP SEQUENCE public.product_product_id_seq;
DROP TABLE public.product;
DROP TABLE public.order_product;
DROP SEQUENCE public.order_order_id_seq;
DROP TABLE public."order";
DROP SEQUENCE public.client_client_id_seq;
DROP TABLE public.client;
DROP TABLE public.address;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE address (
    zip_code character varying NOT NULL,
    street character varying NOT NULL,
    city character varying NOT NULL
);


ALTER TABLE address OWNER TO postgres;

--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE client (
    client_id integer NOT NULL,
    name character varying NOT NULL,
    address_zip_code character varying NOT NULL,
    status character varying
);


ALTER TABLE client OWNER TO postgres;

--
-- Name: client_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE client_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE client_client_id_seq OWNER TO postgres;

--
-- Name: client_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE client_client_id_seq OWNED BY client.client_id;


--
-- Name: order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "order" (
    order_id integer NOT NULL,
    client_id bigint NOT NULL,
    date date NOT NULL,
    delivery_date date
);


ALTER TABLE "order" OWNER TO postgres;

--
-- Name: order_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE order_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE order_order_id_seq OWNER TO postgres;

--
-- Name: order_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE order_order_id_seq OWNED BY "order".order_id;


--
-- Name: order_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE order_product (
    order_id bigint NOT NULL,
    product_id bigint NOT NULL,
    quantity smallint NOT NULL,
    total_price double precision NOT NULL
);


ALTER TABLE order_product OWNER TO postgres;

--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE product (
    product_id integer NOT NULL,
    name character varying NOT NULL,
    price double precision NOT NULL
);


ALTER TABLE product OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE product_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE product_product_id_seq OWNER TO postgres;

--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE product_product_id_seq OWNED BY product.product_id;


--
-- Name: product_total_quantity_sold; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW product_total_quantity_sold AS
 SELECT order_product.product_id,
    product.name,
    sum(order_product.quantity) AS total_quantity
   FROM (order_product
     JOIN product ON ((order_product.product_id = product.product_id)))
  GROUP BY order_product.product_id, product.name;


ALTER TABLE product_total_quantity_sold OWNER TO postgres;

--
-- Name: warehouse; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE warehouse (
    city character varying NOT NULL,
    street character varying NOT NULL
);


ALTER TABLE warehouse OWNER TO postgres;

--
-- Name: warehouse_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE warehouse_product (
    warehouse_city character varying NOT NULL,
    product_id bigint NOT NULL,
    quantity smallint NOT NULL
);


ALTER TABLE warehouse_product OWNER TO postgres;

--
-- Name: client client_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY client ALTER COLUMN client_id SET DEFAULT nextval('client_client_id_seq'::regclass);


--
-- Name: order order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "order" ALTER COLUMN order_id SET DEFAULT nextval('order_order_id_seq'::regclass);


--
-- Name: product product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY product ALTER COLUMN product_id SET DEFAULT nextval('product_product_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY address (zip_code, street, city) FROM stdin;
\.
COPY address (zip_code, street, city) FROM '$$PATH$$/2875.dat';

--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY client (client_id, name, address_zip_code, status) FROM stdin;
\.
COPY client (client_id, name, address_zip_code, status) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "order" (order_id, client_id, date, delivery_date) FROM stdin;
\.
COPY "order" (order_id, client_id, date, delivery_date) FROM '$$PATH$$/2878.dat';

--
-- Data for Name: order_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY order_product (order_id, product_id, quantity, total_price) FROM stdin;
\.
COPY order_product (order_id, product_id, quantity, total_price) FROM '$$PATH$$/2880.dat';

--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY product (product_id, name, price) FROM stdin;
\.
COPY product (product_id, name, price) FROM '$$PATH$$/2881.dat';

--
-- Data for Name: warehouse; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY warehouse (city, street) FROM stdin;
\.
COPY warehouse (city, street) FROM '$$PATH$$/2883.dat';

--
-- Data for Name: warehouse_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY warehouse_product (warehouse_city, product_id, quantity) FROM stdin;
\.
COPY warehouse_product (warehouse_city, product_id, quantity) FROM '$$PATH$$/2884.dat';

--
-- Name: client_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('client_client_id_seq', 150, true);


--
-- Name: order_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('order_order_id_seq', 500, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('product_product_id_seq', 1834, true);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY address
    ADD CONSTRAINT address_pkey PRIMARY KEY (zip_code);


--
-- Name: warehouse city_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse
    ADD CONSTRAINT city_unique UNIQUE (city);


--
-- Name: client client_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY client
    ADD CONSTRAINT client_id_unique UNIQUE (client_id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY client
    ADD CONSTRAINT client_pkey PRIMARY KEY (client_id);


--
-- Name: product name_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY product
    ADD CONSTRAINT name_unique UNIQUE (name);


--
-- Name: order_product order_id_product_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_product
    ADD CONSTRAINT order_id_product_id_unique UNIQUE (order_id, product_id);


--
-- Name: order order_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "order"
    ADD CONSTRAINT order_id_unique UNIQUE (order_id);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (order_id);


--
-- Name: order_product order_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_product
    ADD CONSTRAINT order_product_pkey PRIMARY KEY (order_id, product_id);


--
-- Name: product product_id_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_id_unique UNIQUE (product_id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_pkey PRIMARY KEY (product_id);


--
-- Name: warehouse warehouse_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse
    ADD CONSTRAINT warehouse_pkey PRIMARY KEY (city);


--
-- Name: warehouse_product warehouse_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse_product
    ADD CONSTRAINT warehouse_product_pkey PRIMARY KEY (warehouse_city, product_id);


--
-- Name: warehouse_product warehouse_product_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse_product
    ADD CONSTRAINT warehouse_product_unique UNIQUE (warehouse_city, product_id);


--
-- Name: address zip_code_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY address
    ADD CONSTRAINT zip_code_unique UNIQUE (zip_code);


--
-- Name: fki_address_zip_code_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_address_zip_code_fk ON client USING btree (address_zip_code);


--
-- Name: fki_client_id_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_client_id_fk ON "order" USING btree (client_id);


--
-- Name: fki_order_id_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_order_id_fk ON order_product USING btree (order_id);


--
-- Name: fki_product_id_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_product_id_fk ON order_product USING btree (product_id);


--
-- Name: fki_warehouse_product_product_id_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_warehouse_product_product_id_fk ON warehouse_product USING btree (product_id);


--
-- Name: fki_warehouse_warehouse_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_warehouse_warehouse_fk ON warehouse_product USING btree (warehouse_city);


--
-- Name: client address_zip_code_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY client
    ADD CONSTRAINT address_zip_code_fk FOREIGN KEY (address_zip_code) REFERENCES address(zip_code);


--
-- Name: order client_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "order"
    ADD CONSTRAINT client_id_fk FOREIGN KEY (client_id) REFERENCES client(client_id);


--
-- Name: order_product order_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_product
    ADD CONSTRAINT order_id_fk FOREIGN KEY (order_id) REFERENCES "order"(order_id);


--
-- Name: order_product product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY order_product
    ADD CONSTRAINT product_id_fk FOREIGN KEY (product_id) REFERENCES product(product_id);


--
-- Name: warehouse_product product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse_product
    ADD CONSTRAINT product_id_fk FOREIGN KEY (product_id) REFERENCES product(product_id);


--
-- Name: warehouse_product warehouse_product_product_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse_product
    ADD CONSTRAINT warehouse_product_product_id_fk FOREIGN KEY (product_id) REFERENCES product(product_id);


--
-- Name: warehouse_product warehouse_warehouse_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY warehouse_product
    ADD CONSTRAINT warehouse_warehouse_fk FOREIGN KEY (warehouse_city) REFERENCES warehouse(city);


--
-- PostgreSQL database dump complete
--

